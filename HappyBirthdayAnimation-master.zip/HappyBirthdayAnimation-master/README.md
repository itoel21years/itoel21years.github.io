Happy Birthday Animation
================

This interactive birthday greeting is animated using Velocity.js to target css and svg elements.
There are png fallbacks for browsers that do not support svg. Fallbacks for animation are provided through CSS transforms, CSS animations, as well as CSS sprite sheet animation. 
Browser support is detected using Modernizr, and the appropriate solution is served via JavaScript.